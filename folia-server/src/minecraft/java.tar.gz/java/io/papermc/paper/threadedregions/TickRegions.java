package io.papermc.paper.threadedregions;

// placeholder class for Folia
public class TickRegions {

    public static int getRegionChunkShift() {
        return ca.spottedleaf.moonrise.patches.chunk_system.scheduling.ThreadedTicketLevelPropagator.SECTION_SHIFT;
    }

}
