package net.minecraft.util.debugchart;

public enum TpsDebugDimensions {
    FULL_TICK,
    TICK_SERVER_METHOD,
    SCHEDULED_TASKS,
    IDLE;
}
