package net.minecraft.util;

public @interface VisibleForDebug {
}
