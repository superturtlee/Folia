package net.minecraft.util;

public class CryptException extends Exception {
    public CryptException(Throwable cause) {
        super(cause);
    }
}
