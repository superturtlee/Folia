package net.minecraft;

import java.util.concurrent.Callable;

public interface CrashReportDetail<V> extends Callable<V> {
}
