package net.minecraft.commands;

import net.minecraft.server.commands.PermissionCheck;

public interface PermissionSource {
    boolean hasPermission(int level);

    default boolean allowsSelectors() {
        return this.hasPermission(2);
    }

    public record Check<T extends PermissionSource>(@Override int requiredLevel) implements PermissionCheck<T> {
        @Override
        public boolean test(T source) {
            return source.hasPermission(this.requiredLevel);
        }
    }
}
