package net.minecraft.core;

import com.mojang.serialization.Codec;
import io.netty.buffer.ByteBuf;
import java.util.List;
import net.minecraft.Util;
import net.minecraft.network.codec.StreamCodec;

public record Rotations(float x, float y, float z) {
    public static final Codec<Rotations> CODEC = Codec.FLOAT
        .listOf()
        .comapFlatMap(
            list -> Util.fixedSize((List<Float>)list, 3).map(list1 -> new Rotations(list1.get(0), list1.get(1), list1.get(2))),
            rotations -> List.of(rotations.x(), rotations.y(), rotations.z())
        );
    public static final StreamCodec<ByteBuf, Rotations> STREAM_CODEC = new StreamCodec<ByteBuf, Rotations>() {
        @Override
        public Rotations decode(ByteBuf buffer) {
            return new Rotations(buffer.readFloat(), buffer.readFloat(), buffer.readFloat());
        }

        @Override
        public void encode(ByteBuf buffer, Rotations value) {
            buffer.writeFloat(value.x);
            buffer.writeFloat(value.y);
            buffer.writeFloat(value.z);
        }
    };

    public Rotations(float x, float y, float z) {
        x = !Float.isInfinite(x) && !Float.isNaN(x) ? x % 360.0F : 0.0F;
        y = !Float.isInfinite(y) && !Float.isNaN(y) ? y % 360.0F : 0.0F;
        z = !Float.isInfinite(z) && !Float.isNaN(z) ? z % 360.0F : 0.0F;
        this.x = x;
        this.y = y;
        this.z = z;
    }
}
