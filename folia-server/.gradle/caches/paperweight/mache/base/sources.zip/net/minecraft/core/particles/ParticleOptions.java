package net.minecraft.core.particles;

public interface ParticleOptions {
    ParticleType<?> getType();
}
